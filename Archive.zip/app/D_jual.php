<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class D_jual extends Model
{
    protected $table = "d_jual";
    protected $guarded = ['id'];
    public $timestamps = false;
}
