<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Dummy_pakan extends Model
{
    protected $table = "dummy_pakan";
    protected $guarded = ['id'];
    public $timestamps = false;
}
