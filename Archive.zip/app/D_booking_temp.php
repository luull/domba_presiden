<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class D_booking_temp extends Model
{
    protected $table = "d_booking_temp";
    protected $guarded = ['id'];
    public $timestamps = false;
}
